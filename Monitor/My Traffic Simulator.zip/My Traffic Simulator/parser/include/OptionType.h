#ifndef OPTIONTYPE_H_INCLUDED
#define OPTIONTYPE_H_INCLUDED

enum class OptionType
{
    Boolean,
    Integer,
    Real,
    Text
};

#endif // OPTIONTYPE_H_INCLUDED
