#ifndef DIRECTION_H
#define DIRECTION_H

enum class Direction
{
    goRight = 0,
    goLeft  = 180,
    goUp    = 90,
    goDown  = 270
};

#endif // DIRECTION_H
