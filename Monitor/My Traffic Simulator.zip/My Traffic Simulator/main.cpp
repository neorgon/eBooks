//#include <iostream>
#include <Map.h>

//using namespace std;

int main()
{
    Map m;
	m.createMap(8);
	m.show();
}
