#include "../../thirdParty/googletest/include/gtest/gtest.h"

class ITest : public ::testing::Test
{
	protected:
	virtual void SetUp() {
	
	}
	virtual void TearDown() {
		
	}

};

