#include "../../thirdParty/googletest/include/gtest/gtest.h"

class UTest : public ::testing::Test
{
	protected:
	virtual void SetUp() {
	
	}
	virtual void TearDown() {
		
	}

};

