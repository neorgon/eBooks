#ifndef OPTIONTYPE_H_INCLUDED
#define OPTIONTYPE_H_INCLUDED

enum class OptionType
{
    Integer,
    Real,
    Boolean,
    Text,
    List
};

#endif // OPTIONTYPE_H_INCLUDED
