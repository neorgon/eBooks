
//#include "include/TrafficSimulator.h"
//#include "TrafficSimulator.h"
#include "include/Map.h"

int main()
{
	Map m;
	m.createMap(4);
	m.show();
	//TrafficSimulator* a = new TrafficSimulator(3);
	//a->InitializeVehicles();
}
